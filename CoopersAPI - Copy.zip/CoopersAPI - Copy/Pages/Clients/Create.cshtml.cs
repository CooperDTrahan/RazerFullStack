using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CoopersAPI.Pages.Clients
{
    public class CreateModel : PageModel
    {
        public ClientInfo clientInfo = new ClientInfo();
        //global variable that throws error message
        public String errorMessage = "";
        //global variable that throws succes message
        public String successMessage = "";
        public void OnGet()
        {

        }
        //executes when button submit goes
        public void OnPost()
        {

            clientInfo.name = Request.Form["name"];
            clientInfo.name = Request.Form["email"];
            clientInfo.name = Request.Form["phone"];
            clientInfo.name = Request.Form["address"];
            //if any feild is null it throws back a message
            if (clientInfo.name == null || clientInfo.email == null || clientInfo.phone == null || clientInfo.address == null)
            {
                errorMessage = "All the feilds are required";
                return;
            }
            //save the new client into data base
            clientInfo.name = ""; 
            clientInfo.email = ""; 
            clientInfo.phone = ""; 
            clientInfo.address = "";
            successMessage = "New Client Added correctly I think";
        }
    }
}
